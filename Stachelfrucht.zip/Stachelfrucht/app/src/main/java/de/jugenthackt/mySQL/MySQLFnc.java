package de.jugenthackt.mySQL;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import de.jugenthackt.stachelfrucht.MainActivity;
import de.jugenthackt.stachelfrucht.options;

public class MySQLFnc {

    MySQLCon con = null;

    /*ID wird beim anmelden definiert*/
    public int id = -1;
    public Double Breite = null;
    public Double Laenge = null;
    /*DateTime*/
    public String Zeit = null;

    public String email = null;
    public String Passwort = null;
    /*-1 = n.d 0 = false  1 = true*/


    public void defGPS(int id) throws SQLException{
        PreparedStatement ps = con.connect.prepareStatement("SELECT * FROM GpsData WHERE ID = " + String.valueOf(id) + " LIMIT 1");
        ResultSet rs = ps.executeQuery();
        Breite = rs.getDouble("Breite");
        Laenge = rs.getDouble("Laenge");
        Zeit = rs.getString("Zeit");
    }

    public void defData(int id) throws SQLException{
        PreparedStatement ps = con.connect.prepareStatement("SELECT * FROM User WHERE ID = " + String.valueOf(id) + " LIMIT 1");
        ResultSet rs = ps.executeQuery();
        email = rs.getString("Email");
        Passwort = rs.getString("Passwort");
        options.Status = rs.getInt("Status");
    }

    MainActivity ma = new MainActivity();

    public void startCon(){
        con = new MySQLCon();
        try {
            defGPS(id);
            defData(id);
            ma.refreshStatus();
        }catch (SQLException ex){
            catching();
        }
    }

    public void refresh(){
        try {
            defGPS(id);
            defData(id);
            ma.refreshStatus();
        }catch (SQLException ex){
            catching();
        }
    }

    public void checking(){
        while(true){
            refresh();

        }
    }

    public void catching(){
        /*Layout zu Fehlerlayout setzen*/
    }
}
