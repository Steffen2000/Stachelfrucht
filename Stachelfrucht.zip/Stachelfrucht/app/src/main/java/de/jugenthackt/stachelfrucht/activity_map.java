package de.jugenthackt.stachelfrucht;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;

import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;

import java.util.ArrayList;

public class activity_map extends AppCompatActivity {

    private MapView mMapView;
    private MapController mMapController;
    private GeoPoint gPt;

    protected ItemizedOverlayWithBubble<ExtendedOverlayItem> markerOverlays;
    protected ExtendedOverlayItem markerStart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
        initMap();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            startActivity(new Intent(activity_map.this,Sperren.class));
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    public void initMap(){
        mMapView = (MapView) findViewById(R.id.mapView);
        mMapView.setTileSource(TileSourceFactory.MAPNIK);
        mMapView.setBuiltInZoomControls(true);
        mMapController = (MapController) mMapView.getController();
        mMapController.setZoom(13);


        gPt= new GeoPoint(53.562488 , 9.959889 );
        // gPt= new GeoPoint(0 , 0);
        mMapController.setCenter(gPt);


        //  gPt= new GeoPoint(153.562488 , 9.959889 );
        mMapController.animateTo(gPt);

        GeoPoint myPoint1 = new GeoPoint(53.562488, 9.959889);
        final ArrayList<ExtendedOverlayItem> waypointsItems = new ArrayList<ExtendedOverlayItem>();
        markerOverlays = new ItemizedOverlayWithBubble<ExtendedOverlayItem>(this, waypointsItems, mMapView);
        mMapView.getOverlays().add(markerOverlays);
        markerStart = putMarkerItem(null, myPoint1, "Start", R.drawable.test1, R.drawable.test1);
    }

    public ExtendedOverlayItem putMarkerItem(ExtendedOverlayItem item, GeoPoint p, String title, int markerResId, int iconResId) {
        Drawable marker = getResources().getDrawable(markerResId);
        ExtendedOverlayItem overlayItem = new ExtendedOverlayItem(title, "", p);

        overlayItem.setMarker(marker);
        overlayItem.setImage(getResources().getDrawable(iconResId));
        markerOverlays.addItem(overlayItem);
        mMapView.invalidate();

        return overlayItem;
    }

}
