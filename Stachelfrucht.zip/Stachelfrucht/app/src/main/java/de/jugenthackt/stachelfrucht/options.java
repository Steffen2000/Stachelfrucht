package de.jugenthackt.stachelfrucht;

public class options {

    public static int Status = 0;
}
