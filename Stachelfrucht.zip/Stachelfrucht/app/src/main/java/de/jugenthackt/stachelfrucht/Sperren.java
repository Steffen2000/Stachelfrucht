package de.jugenthackt.stachelfrucht;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import de.jugenthackt.mySQL.MySQLFnc;

public class Sperren extends AppCompatActivity {

    private MySQLFnc fnc = new MySQLFnc();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sperrung);


        ImageView btn_swich =(ImageView)findViewById(R.id.btn_swich);
        btn_swich.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                refreshStatus();
            }
        });

        ImageView btn_GPS =(ImageView)findViewById(R.id.btn_GPS);
        btn_GPS.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){

                startActivity(new Intent(Sperren.this,activity_map.class));
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            startActivity(new Intent(Sperren.this,MainActivity.class));
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    public void refreshStatus(){
        TextView tv = (TextView) findViewById(R.id.Status);
        ImageView iv = (ImageView) findViewById(R.id.btn_swich);
        if(options.Status == 0){
            tv.setText("Deaktiviert");
            tv.setTextColor(getResources().getColor(R.color.colorrot));
            iv.setImageResource(R.drawable.aktivieren);
            options.Status = 1;
        }else{
            tv.setText("Aktiviert");
            tv.setTextColor(getResources().getColor(R.color.colorgruen));
            iv.setImageResource(R.drawable.deaktivieren);
            options.Status = 0;
        }
    }
}
