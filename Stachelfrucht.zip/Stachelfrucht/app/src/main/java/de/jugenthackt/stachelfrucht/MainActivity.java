package de.jugenthackt.stachelfrucht;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


import de.jugenthackt.mySQL.MySQLFnc;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int layout_current = 0;



        ImageView btn_anmelden =(ImageView)findViewById(R.id.btn_anmelden);
        btn_anmelden.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                startActivity(new Intent(MainActivity.this,Sperren.class));
            }
        });


    }



    public void btnAnmelden(View view) {
        System.out.println("Click");
    }

    public void refreshStatus(){
        TextView tv = (TextView) findViewById(R.id.Status);
        ImageView iv = (ImageView) findViewById(R.id.btn_swich);
        if(options.Status == 0){
            tv.setText("Deaktiviert");
            tv.setTextColor(getResources().getColor(R.color.colorrot));
            iv.setImageResource(R.drawable.aktivieren);

        }else{
            tv.setText("Aktiviert");
            tv.setTextColor(getResources().getColor(R.color.colorgruen));
            iv.setImageResource(R.drawable.deaktivieren);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_settings:

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
